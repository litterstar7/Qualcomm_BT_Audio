#
# Copyright (c) 2019-2020 Qualcomm Technologies, Inc. and/or its
# subsidiaries.  All rights reserved.
# Qualcomm Technologies International, Ltd. Confidential and Proprietary.
#
"""
Entry point for KSP CLI.

The script instantiates Pydbg external library and pass it on to the Command
Line controller.
"""
import logging

from csr.front_end.pydbg_front_end import PydbgFrontEnd
from ksp.lib.commandline import KymeraStreamProbeCLI
from ksp.lib.logger import function_logger

logger = logging.getLogger(__name__)


@function_logger(logger)
def main(arguments):
    """Start the TRB and the Interactive Console.

    Args:
        arguments (namespace): A namespace instance of argparse.

    Returns:
        int: 1 if there is an error, 0 otherwise.
    """
    pydbg_config = {
        'device_url': arguments.device_url,
    }
    if arguments.firmware_build:
        pydbg_config['firmware_builds'] = 'apps1:{}'.format(
            arguments.firmware_build
        )

    try:
        device, _ = PydbgFrontEnd.attach(pydbg_config)

    except NotImplementedError as error:
        logger.error("Pydbg error: %s", error)
        return 1

    try:
        device.chip.apps_subsystem.p1.fw.call.OperatorFrameworkEnable(0)
    except UnboundLocalError:
        logger.error("Given firmware doesn't match the chip.")
        return 1

    try:
        cli = KymeraStreamProbeCLI(device)

    except NotImplementedError as error:
        print(error)
        return 1

    cli.cmdloop()
    return 0
