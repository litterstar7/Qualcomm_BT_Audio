#
# Copyright (c) 2019-2020 Qualcomm Technologies, Inc. and/or its
# subsidiaries.  All rights reserved.
# Qualcomm Technologies International, Ltd. Confidential and Proprietary.
#
"""
KSP exception classes.
"""


class ArgumentNotFound(AttributeError):
    """When an invalid input argument is requested.

    This happens when an invalid argument is requested from an instance of
    KSPArgument.
    """


class KSPCapError(RuntimeError):
    """If capability failed to do its job."""


class CommandError(RuntimeError):
    """Given command is invalid."""


class StreamDataError(RuntimeError):
    """When unexpected circumstances is detected."""


class ConfigurationError(RuntimeError):
    """When something goes wrong during a configuration process."""


class InvalidTransformID(ValueError):
    """When a given ID isn't a transform ID."""

class InvalidTransformIDList(ValueError):
    """When a value does not represent a valid transform ID list."""
