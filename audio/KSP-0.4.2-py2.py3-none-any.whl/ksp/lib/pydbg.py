#
# Copyright (c) 2019-2020 Qualcomm Technologies, Inc. and/or its
# subsidiaries.  All rights reserved.
# Qualcomm Technologies International, Ltd. Confidential and Proprietary.
#
"""
Module for starting Kymera Stream Probe (KSP) from pydbg
"""
import logging

from ksp.lib.data_types import KspDataType
from ksp.lib.exceptions import CommandError, KSPCapError
from ksp.lib.logger import method_logger
from ksp.lib.types import TransformID, TransformIDList

logger = logging.getLogger(__name__)


class AppsBuffer():
    """A Buffer management for a ``unint16`` memory location in apps1 memory.

    It is a context manager class. During the instantiation it allocates
    buffers and sets values of the words in place. Once the user exits from
    the context, the buffer will be released.

    Args:
        apps (object): An instance of apps1  class in PyDBG.
        address (Integral): The address in the apps1 memory.
        words (list): A list of words.
        size (int): Size of the buffer.
        owner (int): The owner identifier.
    """
    def __init__(self, apps, words, size, owner=0):
        self._apps = apps
        self._words = words
        self._size = size
        self._owner = owner

        self._address = None

    def _allocate(self):
        self._address = self._apps.fw.call.pmalloc_trace(
            self._size,
            self._owner
        )

    def _set_words(self):
        for offset, word in enumerate(self._words):
            start = self._address + 2 * offset
            end = self._address + 2 * offset + 2
            self._apps.dm[start:end] = [word & 0xFF, word >> 8]

    def _release(self):
        self._apps.fw.call.free(self._address)

    def __enter__(self):
        self._allocate()
        self._set_words()

        return self._address

    def __exit__(self, exc_type, exc_val, exc_tb):
        self._release()


# BUG: B-299422
# pylint: disable=too-few-public-methods,too-many-instance-attributes
class PydbgKspStream():
    """
    Configure, KSP stream from pydbg.

    Args:
        apps1 (apps1 pydbg obj): apps1 pydbg object.
        stream_number (int): stream number, 0 or 1.
        nr_samples (int): number of samples/channel/packet for this stream.
        channel_info (int): channel info type, set it to 0 at the moment.
        data_type (KspDataType):  data_type data type of the stream.
        tr_channels (list representation of TransformIDList): transform
            IDs to trace.
        metadata (bool): enable tracing metadata tags.
    """
    # pylint: disable=too-many-arguments
    @method_logger(logger)
    def __init__(self, stream_number, nr_samples,
                 channel_info, data_type, tr_channels, metadata):
        self.stream_number = stream_number
        self.nr_samples = nr_samples
        self.channel_info = channel_info
        self.data_type = data_type
        self.transforms = tr_channels
        if tr_channels is None:
            self.nr_channels = 0
        else:
            self.nr_channels = TransformIDList.len(tr_channels)
        self.metadata = metadata

    @method_logger(logger)
    def configure(self, opid, apps1):
        """ Configure KSP stream.

        Args:
            opid (int): operator id of the KSP operator.
            apps1 (pydbg apps1 obj): pydbg apps1 object.
        """
        if self.data_type == KspDataType.TTR:
            return self.configure_ttr(opid, apps1)

        words_to_send = [
            0x1,                                    # msg id
            self.stream_number,                     # stream number
            self.nr_channels,                       # number of channels
            self.data_type.value,                   # data type
            self.nr_samples,                        # nr_samples
            self.channel_info                       # channel info
        ]
        # Transform IDs
        words_to_send.extend(TransformIDList.as_int_list(self.transforms))

        # Create memory for send and receive buffers, 12 ``uint16`` words
        # will be enough for both send/receive.
        with AppsBuffer(apps1, [], 2*12) as receive_address:
            with AppsBuffer(apps1, words_to_send, 2*12) as send_address:
                # Send the message, hope for success.
                return_val = apps1.fw.call.OperatorMessage(
                    opid,
                    send_address,
                    self.nr_channels + 6,
                    receive_address,
                    8)

        return return_val

    @method_logger(logger)
    def configure_ttr(self, opid, apps1):
        """ Configure KSP stream of Timing Trace type.

        Args:
            opid (int): operator id of the KSP operator.
            apps1 (pydbg apps1 obj): pydbg apps1 object.
        """
        if self.data_type != KspDataType.TTR:
            return self.configure(opid, apps1)

        enables = 0
        transform_mask = [0] * 16
        if TransformIDList.is_all(self.transforms):
            # No transform filter list means enable all transforms.
            enables |= 3
        elif (
                not TransformIDList.is_none(self.transforms) and
                self.nr_channels > 0
            ):
            enables |= 1
            for tr_ext_id_str in self.transforms:
                tr_int_id = TransformID.get_int_id(int(tr_ext_id_str, 16))
                if TransformID.is_valid_int_id(tr_int_id):
                    index = int(tr_int_id / 16)
                    transform_mask[index] |= (1 << (tr_int_id & 15))
        else:
            # Empty transform filter list means disable buffer level recording.
            pass
        if self.metadata:
            enables |= 4

        words_to_send = [
            0x3,                                    # msg id
            self.stream_number,                     # stream number
            self.nr_samples,                        # nr_samples
            128,                                    # setup buffer size
            2048,                                   # event buffer size
            enables
        ]
        words_to_send.extend(transform_mask)

        # Create memory for send and receive buffers, 12 ``uint16`` words
        # will be enough for both send/receive.
        with AppsBuffer(apps1, [], 2*16) as receive_address:
            with AppsBuffer(apps1, words_to_send, 2*16) as send_address:
                # Send the message, hope for success.
                return_val = apps1.fw.call.OperatorMessage(
                    opid,
                    send_address,
                    len(words_to_send),
                    receive_address,
                    8)

        return return_val


class PydbgKsp():  # pylint: disable=too-many-instance-attributes
    """ Creating, configuring and running KSP stream from pydbg.

    Args:
        apps1 (pydbg apps1 obj): pydbg apps1 object.
        downloadable (bool): set it to True for downloadable.
        edkcs (bool): If True will load a signed downloadable

    Attributes:
        opid (int): KSP operator id.
        running (bool): whether KSP is running now.
        number_of_active_streams (int): number of current active streams.
        streams (dict): all configured streams.
        bdl_ix (int): file index for downloadable file in filesystem.
        loaded (bool): whether downloable is currently loaded.
        cap_id (int): KSP capability ID.

    """
    @method_logger(logger)
    def __init__(self, apps1, downloadable=True, edkcs=False):
        self.apps1 = apps1                 # pydbg apps1 object
        self.opid = 0                      # KSP operator ID
        self.running = False               # KSP operator running
        self.number_of_active_streams = 0  # number_of_active_streams
        self.streams = {}                  # one or two streams
        self.bdl_ix = 0                    # index for KSP.dkcs file in fs
        self.bdl_handle = 0
        self.downloadable = downloadable
        self.loaded = False
        if self.downloadable:
            # set the downloadable file
            if edkcs:
                self.dl_file = "download_ksp.edkcs"
            else:
                self.dl_file = "download_ksp.dkcs"

            # search for downloadable file
            self._get_downloadable_index()
            self.cap_id = 0x4093
        else:
            self.cap_id = 0x00BF

    @method_logger(logger)
    def __del__(self):
        # If running, stop it.
        if self.running:
            self._stop()
        # If created, destroy it.
        if self.opid != 0:
            self._destroy()
        # If loaded, unload it.
        if self.loaded != 0:
            self._unload()

    @method_logger(logger)
    def _get_downloadable_index(self):
        """ Get index for KSP downloadable file in filesystem."""
        def _string_to_charptr(str_txt, no_null=False):
            chars = self.apps1.fw.call.pnew("char", len(str_txt) + 1)
            for i in list(range(len(str_txt))):
                chars[i].value = ord(str_txt[i])
            chars[len(str_txt)].value = ord('X' if no_null else '\0')
            return chars
        bdl_str = _string_to_charptr(self.dl_file)
        self.bdl_ix = self.apps1.fw.call.FileFind(1, bdl_str, len(bdl_str) - 1)
        if self.bdl_ix == 0:
            logger.error("KSP downloadable file not found: %s", self.dl_file)
        else:
            logger.info("KSP downloadable file found, index=%s.", self.bdl_ix)

        self.apps1.fw.call.free(bdl_str)

    @method_logger(logger)
    def _load(self):
        """ Load KSP. """
        if not self.downloadable:
            logger.error("KSP load: not downloadable.")
            return False

        if self.loaded:
            logger.error("KSP load: already loaded.")
            return True

        if self.bdl_ix == 0:
            logger.error("KSP load: no downloadable found.")
            return False

        try:
            bdl = self.apps1.fw.call.OperatorBundleLoad(self.bdl_ix, 0)
        except Exception as error:  # pylint: disable=unused-variable,broad-except
            logger.error("KSP: Failed loading bundle. error=%s", error)
            return False

        if bdl == 0:
            logger.error("KSP: Failed loading bundle. Possibly memory "
                         "shortage or using wrong downloadable, check audio "
                         "log for further clues.")
            return False

        logger.info("KSP bundle is loaded.")
        self.bdl_handle = bdl
        self.loaded = True
        return True

    @method_logger(logger)
    def _unload(self):
        """ Unload KSP."""
        if not self.loaded:
            return True

        self.apps1.fw.call.set_timeout(10)
        ret = self.apps1.fw.call.OperatorBundleUnload(self.bdl_handle)
        if ret == 0:
            raise KSPCapError("Failed unloading the bundle.")

        self.loaded = False
        return True

    # Crate KSP operator.
    @method_logger(logger)
    def _create(self):
        if self.downloadable and not self.loaded:
            logger.error("Can't create KSP op, bundle not loaded.")
            return False

        if self.opid != 0:
            logger.error("Can't create KSP op. It already exists.")
            return False

        try:
            self.opid = self.apps1.fw.call.OperatorCreate(self.cap_id, 0, 0)
        except Exception as error:  # pylint: disable=unused-variable,broad-except
            logger.error("Failed creating KSP op. error=%s", error)
            self.opid = 0
            return False

        if self.opid == 0:
            logger.error("Failed creating KSP op.")
            return False

        return True

    # Destroy KSP operator.
    @method_logger(logger)
    def _destroy(self):

        # Quietly return if not existing.
        if self.opid == 0:
            assert self.number_of_active_streams == 0
            assert not self.running
            return True

        # Check it's not running.
        if self.running:
            logger.error("Can't destroy the running KSP op.")
            return False

        # Destroy op.
        with AppsBuffer(self.apps1, [self.opid], 2) as op_addr:
            ret = self.apps1.fw.call.OperatorDestroyMultiple(1, op_addr, 0)

        if ret == 0:
            logger.error("KSP op not destroyed.")
            return False

        # Destroyed!
        self.opid = 0
        self.number_of_active_streams = 0
        return True

    @method_logger(logger)
    def _configure_op(self):
        """ Configure KSP operator """
        # Check op is existing.
        if self.opid == 0:
            logger.error("Config op failed. KSP operator does not exist.")
            return False

        # Check it isn't running.
        if self.running:
            logger.error("Config op failed. KSP operator is already running.")
            return False

        # Check user has configured at least one stream.
        if not self.streams:
            logger.error("Config op failed. No stream configured by the user.")
            return False

        # Send the config to op.
        self.number_of_active_streams = 0
        for stream_number, stream in self.streams.items():
            if stream.configure(self.opid, self.apps1) == 0:
                logger.error("Configuring stream %s has failed.", stream_number)
                return False

            self.number_of_active_streams += 1
        return True

    @method_logger(logger)
    def _start(self):
        """ Start KSP operator """
        # Check it has been created.
        if self.opid == 0:
            logger.error("Start KSP op failed. Operator does not exist.")
            return False

        # Check it's not running.
        if self.running:
            logger.error("Start KSP op failed. Operator is already running.")
            return False

        # Check that at least one stream is configured.
        if self.number_of_active_streams == 0:
            logger.error("Start KSP op failed. No active stream found.")
            return False

        # Start the operator.
        with AppsBuffer(self.apps1, [self.opid], 2) as op_addr:
            ret = self.apps1.fw.call.OperatorStartMultiple(1, op_addr, 0)

        if ret == 0:
            logger.error("Starting KSP operator failed with %s return id.", ret)
            return False

        # Started now.
        self.running = True
        return True

    @method_logger(logger)
    def _stop(self):
        """ Stop KSP operator """
        # Check that it is running.
        if not self.running:
            return True

        with AppsBuffer(self.apps1, [self.opid], 2) as op_addr:
            ret = self.apps1.fw.call.OperatorStopMultiple(1, op_addr, 0)

        if ret == 0:
            logger.error("Stopping KSP operator failed with %s return id.", ret)
            return False

        # Stopped now.
        self.running = False
        return True

    # pylint: disable=too-many-arguments
    @method_logger(logger)
    def ksp_config_stream(self, stream_number, data_type, tr_channels,
                          nr_samples=0, channel_info=0, metadata=False):
        """ Configures ksp.

        Args:
            stream_number (int): stream id, 0 or 1.
            data_type (KspDataType): stream data type, acceptable values are:
                'DATA16', 'PCM16', 'PCM24','PCM32', 'DATA32' and 'TTR'.
                list KspDataType for latest possible values.
            nr_samples (int): number of samples in each stream packet, up
                to 256, leave it to 0 so audio FW will decide.
            channel_info (int): channel info  type, no use at the moment set it
                to 0 always.
            tr_channels (list): a TransformIDList.
            metadata (bool): enable tracing metadata tags.
        """

        # sanity check the inputs
        if stream_number not in (0, 1):
            error = (
                "KSP Config failed. Stream number "
                "%s is invalid." % stream_number
            )
            logger.error(error)
            raise CommandError(error)
        try:
            data_type = KspDataType[data_type]
        except KeyError:
            error = "KSP Config failed. Data type %s is invalid." % data_type
            logger.error(error)
            raise CommandError(error)
        if nr_samples > 256:
            error = (
                "KSP Config failed. nr_samples is "
                "%s and is bigger than 256." % nr_samples
            )
            logger.error(error)
            raise CommandError(error)
        if channel_info != 0:
            error = (
                "KSP Config failed. channel_info=%s "
                "and not zero" % channel_info
            )
            logger.error(error)
            raise CommandError(error)
        if metadata and data_type != KspDataType.TTR:
            error = (
                "KSP Config failed. Data type "
                "%d and metadata enabled" % data_type
            )
            logger.error(error)
            raise CommandError(error)

        nr_channels = TransformIDList.len(tr_channels)

        if data_type == KspDataType.TTR:
            min_channels = 0
            max_channels = TransformIDList.ALL_LEN
        else:
            min_channels = 1
            if data_type.is_audio_type():
                max_channels = 4
            else:
                max_channels = 1

        if nr_channels < min_channels:
            error = 'Configure at least {} transform ID for stream type {}' \
                    .format(min_channels, str(data_type))
            logger.error(error)
            raise CommandError(error)
        if nr_channels > max_channels:
            error = (
                "KSP Config failed. {} channels requested, "
                "max {} channels supported for stream "
                "type {}" .format(nr_channels, max_channels, str(data_type))
            )
            logger.error(error)
            raise CommandError(error)

        # Clear stream if already configured.
        if stream_number in self.streams:
            del self.streams[stream_number]

        # Add stream config.
        self.streams[stream_number] = PydbgKspStream(
            stream_number,
            nr_samples,
            channel_info,
            data_type,
            tr_channels,
            metadata
        )

    @method_logger(logger)
    def ksp_start(self):
        """ Starting KSP """
        if self.downloadable and not self.loaded:
            if not self._load():
                raise KSPCapError("Cannot load the downloadable.")

        # Create KSP op.
        if self.opid == 0:
            if not self._create():
                raise KSPCapError("Cannot create the KSP operator.")

        # Configure KSP op.
        if not self._configure_op():
            raise KSPCapError("Cannot configure the KSP operator.")

        # Start KSP op.
        if not self._start():
            raise KSPCapError("Cannot start the KSP operator.")

        return self.opid

    @method_logger(logger)
    def ksp_stop(self):
        """
        Stopping KSP
        """

        # Stop KSP operator
        if not self._stop():
            return False

        # Destroy KSP operator
        if not self._destroy():
            return False

        return True
