#
# Copyright (c) 2020 Qualcomm Technologies, Inc. and/or its subsidiaries.
# All rights reserved.
# Qualcomm Technologies International, Ltd. Confidential and Proprietary.
#
"""
Boilerplate for various chip interfaces.
"""
import logging
import threading

import ksp.lib.namespace as ns
from ksp.lib.exceptions import KSPCapError, CommandError
from ksp.lib.logger import method_logger
from ksp.lib.pydbg import PydbgKsp
from ksp.lib.trb import Ksp
from ksp.lib.types import TransformIDList

logger = logging.getLogger(__name__)
TRB_NUMBER_OF_TRANSACTIONS = 100


# The number of instance attributes related to `GenericChip` class is
# expected and neccessary for a boiler plate.
# pylint: disable=too-many-instance-attributes
class GenericChip(object):
    """A boilerplate class for chips implementations.

    Args:
        device (object): Device instance object comes from pydbg library.
    """
    PYDBG_DOWNLOADABLE = True
    PYDBG_EDKCS = True

    @method_logger(logger)
    def __init__(self, device):
        self._dongle_name = device.transport.dongle_name
        self._dongle_id = device.transport.trb.get_dongle_details().id

        self._apps0, self._apps1 = (
            device.chip.apps_subsystem.p0,
            device.chip.apps_subsystem.p1
        )

        self._read_stop_event = threading.Event()
        self._read_data_process = None

        self._ksp_pydbg = None
        self._ksp_trb = None

    @method_logger(logger)
    def start_probe(self, output_filename, config):
        """Starts the prob based on the given configurations.

        Args:
            output_filename (str): A filename that output which KSP will
                write into it.
            config (dict): A dictionary configuration which the keys are
                exactly the same as KymeraStreamProbeCLI's configuration.

        Raises:
            CommandError: When there is a prob running.
        """
        if self._read_data_process and self._read_data_process.is_alive():
            raise CommandError("The prob is already running.")

        self._reset()

        self._init_ksp_trb()
        self._init_ksp_pydbg(config)

        self._start_ksp_trb(output_filename)
        try:
            op_id = self._start_ksp_pydbg()

        except KSPCapError:
            # Communication to the KSP cap is failed. Stop the reader.
            self._stop_ksp_trb()
            raise

        return op_id

    @method_logger(logger)
    def stop_probe(self):
        """Stops the running prob.

        Raises:
            CommandError: When the prob is already stopped.
        """
        try:
            self._stop_ksp_pydbg()
            self._stop_ksp_trb()

        except CommandError:
            raise CommandError("The prob is already stopped.")

        finally:
            self._reset()

    @method_logger(logger)
    def is_running(self):
        """Checks whether the prob is already running.

        Returns:
            bool: True if the prob is running, False otherwise.
        """
        ksp_trb_running = False
        ksp_pydbg_running = False

        if self._read_data_process and self._read_data_process.is_alive():
            ksp_trb_running = True
        if self._ksp_pydbg and self._ksp_pydbg.running:
            ksp_pydbg_running = True

        return all((ksp_trb_running, ksp_pydbg_running))

    @method_logger(logger)
    def _start_ksp_trb(self, output_filename):
        self._read_data_process = threading.Thread(
            target=self._ksp_trb.read_data,
            args=(
                output_filename,
                self._read_stop_event,
            ),
            kwargs={'verbose': True}
        )

        self._read_data_process.start()

    @method_logger(logger)
    def _stop_ksp_trb(self):
        if self._ksp_trb is None:
            raise CommandError("KSP TRB is not running.")

        self._read_stop_event.set()
        self._read_data_process.join()

    @method_logger(logger)
    def _start_ksp_pydbg(self):
        try:
            return self._ksp_pydbg.ksp_start()

        except KSPCapError as error:
            logger.error(error)
            raise

    @method_logger(logger)
    def _stop_ksp_pydbg(self):
        if self._ksp_pydbg is None:
            raise CommandError("KSP Pydbg is not running.")

        try:
            self._ksp_pydbg.ksp_stop()

        except KSPCapError as error:
            logger.error(error)
            raise

    @method_logger(logger)
    def _reset(self):
        if self.is_running():
            self._stop_ksp_trb()
            self._stop_ksp_pydbg()

        self._read_stop_event.clear()
        self._read_data_process = None

        self._ksp_trb = None
        self._ksp_pydbg = None

    @method_logger(logger)
    def _init_ksp_trb(self):
        self._ksp_trb = Ksp(
            device=self._dongle_name,
            device_id=self._dongle_id,
            num_transactions=TRB_NUMBER_OF_TRANSACTIONS,
        )

    @method_logger(logger)
    def _init_ksp_pydbg(self, config):
        self._ksp_pydbg = PydbgKsp(
            self._apps1,
            downloadable=self.PYDBG_DOWNLOADABLE,
            edkcs=self.PYDBG_EDKCS,
        )

        for stream_num, stream_dict in config[ns.STREAMS].items():
            self._ksp_pydbg.ksp_config_stream(
                stream_num,
                stream_dict[ns.STREAMS_DATA_TYPE],
                TransformIDList(stream_dict[ns.STREAMS_TRANSFORM_IDS]),
                nr_samples=stream_dict.get(ns.STREAMS_SAMPLES, 0),
                metadata=stream_dict.get(ns.STREAMS_METADATA, False)
            )
