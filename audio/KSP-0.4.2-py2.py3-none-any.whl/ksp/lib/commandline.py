#
# Copyright (c) 2020 Qualcomm Technologies, Inc. and/or its subsidiaries.
# All rights reserved.
# Qualcomm Technologies International, Ltd. Confidential and Proprietary.
#
"""
Core KSP Command Line Interface.
"""
import logging
import os
import sys

from cmd import Cmd

import ksp.lib.namespace as ns
from ksp.lib import configurations
from ksp.lib.chips.factory import chip_factory
from ksp.lib.common import get_input
from ksp.lib.exceptions import KSPCapError, CommandError, ConfigurationError
from ksp.lib.extractor import LrwStreamExtractor
from ksp.lib.logger import method_logger
from ksp.lib.pretty import PrettyDictionaryPrinter
from ksp.lib.types import Stream

logger = logging.getLogger(__name__)

CURRENT_DIRECTORY = os.path.dirname(os.path.realpath(__file__))


class InteractiveBaseCLI(Cmd, object):
    """CLI Base"""
    @method_logger(logger)
    def __init__(self):
        super(InteractiveBaseCLI, self).__init__(
            completekey='tab',
            stdin=None,
            stdout=None
        )


class KymeraStreamProbeCLI(InteractiveBaseCLI):
    """Kymera Stream Probe CLI.

    Args:
        device (object): A device instance from pydbg tool.
    """
    prompt = 'KSP> '
    intro = (
        "Welcome to Kymera Stream Probe (KSP) CLI!\n"
        "To get the list of commands typel `help`. For command helps\n"
        "use `help [COMMAND]`. Use `exit` command to quit."
    )

    STREAM_DATA_TYPES = ['PCM16', 'PCM24', 'PCM32', 'DATA16', 'DATA32', 'TTR']

    @method_logger(logger)
    def __init__(self, device):
        self._device = device

        self._config = {}
        self._init_configurations()

        self._ksp_pydbg = None

        self._chip = chip_factory(device)

        super(KymeraStreamProbeCLI, self).__init__()

    @method_logger(logger)
    def postcmd(self, stop, line):
        """Executes after each input command."""
        print('')
        return super(KymeraStreamProbeCLI, self).postcmd(stop, line)

    @method_logger(logger)
    def do_remove_stream(self, stream_number):
        """
        Remove the given stream number from streams.
        """
        try:
            stream_number = int(stream_number)
            if stream_number in self._config[ns.STREAMS].keys():
                del self._config[ns.STREAMS][stream_number]
                return

            logger.error("Stream number not found.")
            return

        except ValueError:
            logger.error("Stream number should be an integer.")
            return

    # BUG: B-299459 "Refactor Stream object"
    # pylint: disable=too-many-locals,too-many-branches,too-many-statements
    @method_logger(logger)
    def do_config_stream(self, stream_number):
        """
        Configure a stream.

        The command asks stream parameters from the user and populate the
        CLI's configuration based on them. CLI uses these parameters to start
        KSP and perform appropriate extractions.

        Args:
            stream_number (int): The stream number.
        """
        if not stream_number.strip():
            logger.error("Please enter a valid stream number.")
            return
        try:
            stream_number = int(stream_number)
            if stream_number not in Stream.SUPPORTED_STREAMS:
                logger.error("Entered stream number is not supported.")
                return

        except ValueError:
            logger.error("Stream number should be an integer.")
            return

        # If the stream is already configured, read the current values and
        # use its properties as defaults.
        if stream_number in self._config[ns.STREAMS]:
            stream = self._config[ns.STREAMS][stream_number]
            default_data_type = stream[ns.STREAMS_DATA_TYPE]
            default_transform_ids = stream[ns.STREAMS_TRANSFORM_IDS]
            # Optional attributes.
            default_samples = stream.get(ns.STREAMS_SAMPLES, 0)
            default_sample_rate = stream.get(ns.STREAMS_SAMPLE_RATE, 0)
            default_metadata = "n"
            if default_data_type == "TTR":
                default_metadata_bool = stream.get(ns.STREAMS_METADATA, False)
                if default_metadata_bool:
                    default_metadata = "y"
        else:
            default_data_type = None
            default_transform_ids = None
            default_samples = 0
            default_sample_rate = 0
            default_metadata = "n"

        data_type = get_input(ns.STREAMS_DATA_TYPE, default_data_type)
        if data_type.upper() == 'TTR':
            transform_help = "Space separated IDs or 'all' or 'none'"
        else:
            transform_help = "Space separated IDs"
        transform_ids = get_input(
            '{field} ({help})'.format(
                field=ns.STREAMS_TRANSFORM_IDS,
                help=transform_help
            ),
            default_transform_ids
        ).split()

        # Optional samples for stream.
        samples = int(get_input(ns.STREAMS_SAMPLES, default_samples))

        # Optional metadata enable for TTR streams
        if data_type.upper() == 'TTR':
            metadata_str = get_input(
                '{field} (y/n)'.format(
                    field=ns.STREAMS_METADATA
                ),
                default_metadata
            )
            metadata = metadata_str[0] in "YyTt"

        else:
            metadata = False

        # Optional sample rate for stream.
        if data_type.upper() == 'TTR':
            sample_rate = 0
        else:
            sample_rate = int(
                get_input(ns.STREAMS_SAMPLE_RATE, default_sample_rate)
            )

        try:
            stream = Stream(
                stream_number,
                data_type,
                transform_ids,
                samples=samples,
                sample_rate=sample_rate,
                metadata=metadata
            )
            # Remove the stream number from the dictionary as ``self._config``
            # already knows about the ``stream_number``.
            # BUG: B-299459 "Refactor Stream object"
            # pylint: disable=unsupported-delete-operation
            del stream[ns.STREAMS_STREAM]
            # pylint: enable=unsupported-delete-operation

            self._config[ns.STREAMS][stream_number] = stream
        except ConfigurationError as error:
            logger.error(error)

    # BUG: B-299459 "Refactor Stream object"
    # pylint: enable=too-many-locals,too-many-branches,too-many-statements

    @method_logger(logger)
    def do_config(self, _):
        """Display the current configurations."""
        printer = PrettyDictionaryPrinter(
            4,
            self._config,
            title="Current Configurations:"
        )
        printer.pprint()

    @method_logger(logger)
    def _extract(self):
        if os.path.isfile(self._config[ns.OUTPUT_FILENAME]) is False:
            print("WARNING: Output file does not exist!")
            return

        if os.path.getsize(self._config[ns.OUTPUT_FILENAME]) == 0:
            print("WARNING: Output file is empty!")
            return

        # get all configured sample rates to the extractor
        sample_rates = {}
        configured_streams = self._config[ns.STREAMS]

        for stream_id in Stream.SUPPORTED_STREAMS:
            if stream_id in configured_streams:
                stream = configured_streams[stream_id]
                sample_rates[stream_id] = stream.get(
                    ns.STREAMS_SAMPLE_RATE, 0
                )

        extractor = LrwStreamExtractor(
            self._config[ns.OUTPUT_FILENAME],
            sample_rates=sample_rates
        )
        result = extractor.extract()

        printer = PrettyDictionaryPrinter(4, result, title="Streams:")
        printer.pprint()

    @method_logger(logger)
    def do_set_output_filename(self, arg):
        """Set the output filename, where the data is going to be saved."""
        directory = os.path.split(arg)[0]
        if len(directory) != 0 and os.path.exists(directory) is False:
            os.makedirs(directory)

        self._config[ns.OUTPUT_FILENAME] = arg

    @method_logger(logger)
    def do_start(self, _):
        """Start the KSP with the current configurations."""
        if len(self._config[ns.OUTPUT_FILENAME].strip()) == 0:
            print("Error: You must specify the output filename.")
            return
        if len(self._config[ns.STREAMS]) == 0:
            print("Error: You must configure at least one stream.")
            return

        try:
            op_id = self._chip.start_probe(
                self._config[ns.OUTPUT_FILENAME],
                self._config,
            )
            print('Operator ID: {}'.format(hex(op_id)))

            print("\nPress Enter to stop the prob.")
            sys.stdin.read(1)

            self._chip.stop_probe()
            self._extract()

            # Operation was successful, save the configuration.
            configurations.save(**self._config)

        except KSPCapError as error:
            print(error)

        except CommandError as error:
            print(error)

    # This method can not be static as it's integral to how the command
    # prompt works.
    # pylint: disable=no-self-use
    @method_logger(logger)
    def do_exit(self, _):
        """Exits the KSP app."""
        print("Thanks for using Kymera Stream Probe (KSP). Goodbye!")
        return True
    # pylint: enable=no-self-use

    def _init_configurations(self):
        # Check if there is any saved configurations. If nothing found, this
        # method populates the ``self._config`` with default values.
        config = configurations.retrieve()
        streams = config.get(ns.STREAMS)
        if streams:
            self._config[ns.STREAMS] = {}
            for num, stream_dict in streams.items():
                self._config[ns.STREAMS][int(num)] = stream_dict
        else:
            self._config[ns.STREAMS] = {}

        self._config[ns.OUTPUT_FILENAME] = config.get(ns.OUTPUT_FILENAME, '')
