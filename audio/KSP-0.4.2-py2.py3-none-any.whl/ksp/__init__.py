#
# Copyright (c) 2020 Qualcomm Technologies, Inc. and/or its subsidiaries.
# All rights reserved.
# Qualcomm Technologies International, Ltd. Confidential and Proprietary.
#
"""
Entry points functions.
"""
import os

from ksp._version import __version__


def get_documents():
    """Gives documentation information."""
    current_directory = os.path.dirname(os.path.realpath(__file__))
    doc_index = os.path.join(current_directory, 'docs', 'index.html')
    return dict(
        title="KSP {} Documentation".format(__version__),
        location=doc_index,
        summary="Kymera Stream Probe User Guide.",
        rank=12
    )
